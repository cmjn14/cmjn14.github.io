# Foam tips

_For up-to-date tips, see [Foam Recipes](https://foambubble.github.io/foam/recipes)._
