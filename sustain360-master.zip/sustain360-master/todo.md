# Todo

- [x] This is an example of a todo list item that's complete
- [x] Todo lists are useful for keeping organised and focused
- [ ] This one is not completed yet
- [ ] You can mark it completed by pressing `Option`+`C` (or `Alt`+`C`) when your cursor is on this line
  - [ ] You can also select multiple lines and mark them all at once!
- [ ] When you press enter at the end of a line, it adds a new todo item on the next line
- [ ] This, and more is provided by the [Markdown All in One](https://marketplace.visualstudio.com/items?itemName=yzhang.markdown-all-in-one) plugin by [Yu Zhang](https://github.com/yzhang-gh)
